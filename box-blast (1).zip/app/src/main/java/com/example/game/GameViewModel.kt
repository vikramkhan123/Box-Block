package com.example.game

import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

data class GameState(
    val grid: List<List<GridCell>> = emptyList(),
    val trayBlocks: List<BlockPiece?> = emptyList(),
    val score: Int = 0,
    val isGameOver: Boolean = false,
    val comboMessage: String? = null,
    val gameMode: GameMode = GameMode.CLASSIC,
    val targetStars: Int = 0,
    val targetDiamonds: Int = 0,
    val collectedStars: Int = 0,
    val collectedDiamonds: Int = 0
)

class GameViewModel : ViewModel() {
    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    private var pieceIdCounter = 0
    private val gridSize = 8

    fun initGame(mode: GameMode) {
        val initialGrid = List(gridSize) { y ->
            List(gridSize) { x -> GridCell(x, y) }
        }
        
        _state.value = GameState(
            grid = initialGrid,
            trayBlocks = List(3) { generateRandomPiece(mode) },
            gameMode = mode,
            targetStars = if (mode == GameMode.ADVENTURE) 15 else 0,
            targetDiamonds = if (mode == GameMode.ADVENTURE) 10 else 0
        )
    }

    private fun generateRandomPiece(mode: GameMode): BlockPiece {
        val shape = BlockShapes.allShapes.random()
        val color = BlockColors.random()
        var gemType = GemType.NONE
        
        if (mode == GameMode.ADVENTURE) {
            if (Random.nextFloat() > 0.6f) { // 40% chance of gem
                // Ensure contrast
                val allowedGems = mutableListOf<GemType>()
                if (color != BlockIndigo && color != BlockTeal) allowedGems.add(GemType.DIAMOND)
                if (color != BlockOrange) allowedGems.add(GemType.STAR)
                
                if (allowedGems.isNotEmpty()) {
                    gemType = allowedGems.random()
                } else {
                    gemType = GemType.HEART
                }
            }
        }
        
        return BlockPiece(
            id = pieceIdCounter++,
            shape = shape,
            color = color,
            gemType = gemType
        )
    }

    fun canPlacePiece(piece: BlockPiece, startX: Int, startY: Int): Boolean {
        val currentGrid = _state.value.grid
        for (point in piece.shape) {
            val gridX = startX + point.first
            val gridY = startY + point.second
            if (gridX !in 0 until gridSize || gridY !in 0 until gridSize) return false
            if (currentGrid[gridY][gridX].block != null) return false
        }
        return true
    }

    fun placePiece(piece: BlockPiece, startX: Int, startY: Int, trayIndex: Int) {
        if (!canPlacePiece(piece, startX, startY)) return
        
        val currentState = _state.value
        val newGrid = currentState.grid.map { row -> row.toMutableList() }.toMutableList()
        
        for (point in piece.shape) {
            val gridX = startX + point.first
            val gridY = startY + point.second
            newGrid[gridY][gridX] = newGrid[gridY][gridX].copy(block = BlockCell(piece.color, piece.gemType))
        }
        
        var starsCollected = currentState.collectedStars
        var diamondsCollected = currentState.collectedDiamonds
        
        // Clear lines
        val rowsToClear = mutableListOf<Int>()
        val colsToClear = mutableListOf<Int>()
        
        for (y in 0 until gridSize) {
            if (newGrid[y].all { it.block != null }) rowsToClear.add(y)
        }
        for (x in 0 until gridSize) {
            if (newGrid.all { it[x].block != null }) colsToClear.add(x)
        }
        
        val totalLinesCleared = rowsToClear.size + colsToClear.size
        
        // Count gems in cleared lines before clearing
        if (totalLinesCleared > 0 && currentState.gameMode == GameMode.ADVENTURE) {
            val cellsToClear = mutableSetOf<Pair<Int, Int>>()
            rowsToClear.forEach { y ->
                for (x in 0 until gridSize) cellsToClear.add(Pair(x, y))
            }
            colsToClear.forEach { x ->
                for (y in 0 until gridSize) cellsToClear.add(Pair(x, y))
            }
            
            cellsToClear.forEach { (x, y) ->
                val block = newGrid[y][x].block
                if (block != null) {
                    if (block.gemType == GemType.STAR) starsCollected++
                    if (block.gemType == GemType.DIAMOND) diamondsCollected++
                }
            }
        }
        
        // Clear them
        rowsToClear.forEach { y ->
            for (x in 0 until gridSize) newGrid[y][x] = newGrid[y][x].copy(block = null)
        }
        colsToClear.forEach { x ->
            for (y in 0 until gridSize) newGrid[y][x] = newGrid[y][x].copy(block = null)
        }
        
        val comboMsg = when {
            totalLinesCleared >= 3 -> "MAGNIFICENT!"
            totalLinesCleared == 2 -> "EXCELLENT!"
            totalLinesCleared == 1 -> "GOOD!"
            else -> null
        }
        
        val newScore = currentState.score + piece.shape.size + (totalLinesCleared * 10)
        
        val newTrayBlocks = currentState.trayBlocks.toMutableList()
        newTrayBlocks[trayIndex] = generateRandomPiece(currentState.gameMode)
        
        _state.update {
            it.copy(
                grid = newGrid,
                trayBlocks = newTrayBlocks,
                score = newScore,
                comboMessage = comboMsg,
                collectedStars = starsCollected,
                collectedDiamonds = diamondsCollected
            )
        }
        
        checkGameOver()
    }
    
    private fun checkGameOver() {
        val st = _state.value
        val anyCanBePlaced = st.trayBlocks.filterNotNull().any { piece ->
            var canPlace = false
            for (y in 0 until gridSize) {
                for (x in 0 until gridSize) {
                    if (canPlacePiece(piece, x, y)) {
                        canPlace = true
                        break
                    }
                }
                if (canPlace) break
            }
            canPlace
        }
        
        if (!anyCanBePlaced) {
            _state.update { it.copy(isGameOver = true) }
        }
    }
    
    fun clearComboMessage() {
        _state.update { it.copy(comboMessage = null) }
    }
    
    fun watchAdToRevive() {
        // clear a 3x3 area in the center
        val center = gridSize / 2
        val currentState = _state.value
        val newGrid = currentState.grid.map { it.toMutableList() }.toMutableList()
        for (y in center-1..center+1) {
            for (x in center-1..center+1) {
                if (y in 0 until gridSize && x in 0 until gridSize) {
                    newGrid[y][x] = newGrid[y][x].copy(block = null)
                }
            }
        }
        _state.update { it.copy(grid = newGrid, isGameOver = false) }
        checkGameOver()
    }
}
