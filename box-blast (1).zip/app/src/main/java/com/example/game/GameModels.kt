package com.example.game

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class GameMode {
    CLASSIC, ADVENTURE
}

enum class GemType(val color: Color) {
    NONE(Color.Transparent),
    STAR(GemStarGold),
    DIAMOND(GemDiamondIce),
    HEART(GemHotPink)
}

data class BlockCell(
    val color: Color,
    val gemType: GemType = GemType.NONE
)

// A block piece that the user can drag
data class BlockPiece(
    val id: Int,
    val shape: List<Pair<Int, Int>>, // coordinates relative to 0,0
    val color: Color,
    val gemType: GemType = GemType.NONE
) {
    val width: Int = shape.maxOfOrNull { it.first }?.plus(1) ?: 0
    val height: Int = shape.maxOfOrNull { it.second }?.plus(1) ?: 0
}

data class GridCell(
    val x: Int,
    val y: Int,
    val block: BlockCell? = null
)

object BlockShapes {
    val single = listOf(Pair(0,0))
    val line2H = listOf(Pair(0,0), Pair(1,0))
    val line2V = listOf(Pair(0,0), Pair(0,1))
    val line3H = listOf(Pair(0,0), Pair(1,0), Pair(2,0))
    val line3V = listOf(Pair(0,0), Pair(0,1), Pair(0,2))
    val line4H = listOf(Pair(0,0), Pair(1,0), Pair(2,0), Pair(3,0))
    val line4V = listOf(Pair(0,0), Pair(0,1), Pair(0,2), Pair(0,3))
    val square2x2 = listOf(Pair(0,0), Pair(1,0), Pair(0,1), Pair(1,1))
    val square3x3 = listOf(Pair(0,0), Pair(1,0), Pair(2,0), Pair(0,1), Pair(1,1), Pair(2,1), Pair(0,2), Pair(1,2), Pair(2,2))
    val LShape = listOf(Pair(0,0), Pair(0,1), Pair(0,2), Pair(1,2))
    val LShapeRev = listOf(Pair(1,0), Pair(1,1), Pair(1,2), Pair(0,2))
    val TShape = listOf(Pair(0,0), Pair(1,0), Pair(2,0), Pair(1,1))
    
    val allShapes = listOf(
        single, line2H, line2V, line3H, line3V, line4H, line4V, square2x2, square3x3, LShape, LShapeRev, TShape
    )
}
