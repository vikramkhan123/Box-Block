package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.game.GemType

@Composable
fun BlockView(color: Color, gemType: GemType, size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .padding(1.dp)
            .shadow(4.dp, RoundedCornerShape(4.dp))
            .clip(RoundedCornerShape(4.dp))
            .background(color)
            .drawBehind {
                // 3D Bevel effect
                val strokeWidth = size.toPx() * 0.15f
                val lightColor = Color.White.copy(alpha = 0.3f)
                val darkColor = Color.Black.copy(alpha = 0.5f)
                
                // Top border
                drawPath(
                    path = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(size.toPx(), 0f)
                        lineTo(size.toPx() - strokeWidth, strokeWidth)
                        lineTo(strokeWidth, strokeWidth)
                        close()
                    },
                    color = lightColor
                )
                // Left border
                drawPath(
                    path = Path().apply {
                        moveTo(0f, 0f)
                        lineTo(strokeWidth, strokeWidth)
                        lineTo(strokeWidth, size.toPx() - strokeWidth)
                        lineTo(0f, size.toPx())
                        close()
                    },
                    color = lightColor
                )
                // Bottom border
                drawPath(
                    path = Path().apply {
                        moveTo(0f, size.toPx())
                        lineTo(strokeWidth, size.toPx() - strokeWidth)
                        lineTo(size.toPx() - strokeWidth, size.toPx() - strokeWidth)
                        lineTo(size.toPx(), size.toPx())
                        close()
                    },
                    color = darkColor
                )
                // Right border
                drawPath(
                    path = Path().apply {
                        moveTo(size.toPx(), 0f)
                        lineTo(size.toPx() - strokeWidth, strokeWidth)
                        lineTo(size.toPx() - strokeWidth, size.toPx() - strokeWidth)
                        lineTo(size.toPx(), size.toPx())
                        close()
                    },
                    color = darkColor
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (gemType != GemType.NONE) {
            // Socket (Layer 2)
            Box(
                modifier = Modifier
                    .size(size * 0.6f)
                    .clip(RoundedCornerShape(percent = 20))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .border(1.dp, Color.Black, RoundedCornerShape(percent = 20)),
                contentAlignment = Alignment.Center
            ) {
                // Gem (Layer 3)
                val icon: ImageVector = when (gemType) {
                    GemType.STAR -> Icons.Filled.Star
                    GemType.DIAMOND -> Icons.Filled.Star // Using star shape for diamond as fallback since Filled.Diamond might not exist in standard material icons extended. Wait, let's use a standard vector or custom shape. 
                    GemType.HEART -> Icons.Filled.Favorite
                    else -> Icons.Filled.Star
                }
                
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = gemType.color,
                    modifier = Modifier
                        .size(size * 0.45f)
                        // Glowing effect simulation
                        .drawBehind {
                            drawCircle(
                                color = gemType.color.copy(alpha = 0.4f),
                                radius = size.toPx() * 0.3f
                            )
                        }
                )
            }
        }
    }
}
