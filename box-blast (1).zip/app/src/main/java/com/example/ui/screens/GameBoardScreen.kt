package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.*
import com.example.ui.components.BlockView
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun GameBoardScreen(
    viewModel: GameViewModel,
    onBack: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BackgroundGradientStart, BackgroundGradientEnd)))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            var gridRootOffset by remember { mutableStateOf(Offset.Zero) }
            var cellSizePx by remember { mutableStateOf(1f) } // default 1f to avoid div by zero
            
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f))) {
                    Text("Back", color = Color.White)
                }
                
                Text(
                    text = "SCORE: ${state.score}",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Grid and Gameplay Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val density = LocalDensity.current
                
                // The Grid
                Column(
                    modifier = Modifier
                        .background(GridBackground, RoundedCornerShape(8.dp))
                        .padding(4.dp)
                        .onGloballyPositioned { layoutCoordinates ->
                            gridRootOffset = layoutCoordinates.positionInRoot()
                            cellSizePx = with(density) { (layoutCoordinates.size.width - 8.dp.toPx()) / 8f }
                        }
                ) {
                    state.grid.forEachIndexed { y, row ->
                        Row {
                            row.forEachIndexed { x, cell ->
                                Box(
                                    modifier = Modifier
                                        .size(36.dp) // Base size, scales on smaller screens
                                        .padding(1.dp)
                                        .background(GridCellEmpty, RoundedCornerShape(2.dp))
                                        .border(1.dp, GridCellBorder, RoundedCornerShape(2.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    cell.block?.let {
                                        BlockView(color = it.color, gemType = it.gemType, size = 34.dp)
                                    }
                                }
                            }
                        }
                    }
                }
                
                // Combo message overlay
                Column {
                    AnimatedVisibility(
                        visible = state.comboMessage != null,
                        enter = fadeIn() + slideInVertically(initialOffsetY = { 100 }),
                        exit = fadeOut()
                    ) {
                        Text(
                            text = state.comboMessage ?: "",
                            style = TextStyle(
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = GemStarGold,
                                shadow = Shadow(color = Color.Black, offset = Offset(0f, 4f), blurRadius = 8f)
                            )
                        )
                    }
                }
                
                LaunchedEffect(state.comboMessage) {
                    if (state.comboMessage != null) {
                        delay(1500)
                        viewModel.clearComboMessage()
                    }
                }
            }
            
            // Block Tray
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val density = LocalDensity.current
                
                state.trayBlocks.forEachIndexed { index, piece ->
                    var trayItemRoot by remember { mutableStateOf(Offset.Zero) }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .onGloballyPositioned { trayItemRoot = it.positionInRoot() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (piece != null) {
                            DraggablePiece(
                                piece = piece,
                                cellSize = 36.dp,
                                onDragEnd = { offset ->
                                    val finalPos = trayItemRoot + offset
                                    val localGridPos = finalPos - gridRootOffset
                                    
                                    val paddingAdjustment = 4.dp.value * density.density
                                    val gridX = ((localGridPos.x - paddingAdjustment) / cellSizePx).roundToInt()
                                    val gridY = ((localGridPos.y - paddingAdjustment) / cellSizePx).roundToInt()
                                    
                                    if (viewModel.canPlacePiece(piece, gridX, gridY)) {
                                        viewModel.placePiece(piece, gridX, gridY, index)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
        
        // Game Over Overlay
        if (state.isGameOver) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.padding(32.dp),
                    colors = CardDefaults.cardColors(containerColor = BackgroundGradientStart)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "OUT OF MOVES",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "Score: ${state.score}", color = Color.White, fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        Button(
                            onClick = { viewModel.watchAdToRevive() },
                            colors = ButtonDefaults.buttonColors(containerColor = ButtonAdventureStart),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Watch Ad to Revive")
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Button(
                            onClick = { viewModel.initGame(state.gameMode) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Play Again")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DraggablePiece(
    piece: BlockPiece,
    cellSize: Dp,
    onDragEnd: (Offset) -> Unit
) {
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var isDragging by remember { mutableStateOf(false) }
    
    Box(
        modifier = Modifier
            .offset { IntOffset(dragOffset.x.roundToInt(), dragOffset.y.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { isDragging = true },
                    onDragEnd = {
                        isDragging = false
                        onDragEnd(dragOffset)
                        dragOffset = Offset.Zero
                    },
                    onDragCancel = {
                        isDragging = false
                        dragOffset = Offset.Zero
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragOffset += dragAmount
                    }
                )
            }
    ) {
        Column {
            for (y in 0 until piece.height) {
                Row {
                    for (x in 0 until piece.width) {
                        if (piece.shape.contains(Pair(x, y))) {
                            BlockView(color = piece.color, gemType = piece.gemType, size = cellSize)
                        } else {
                            Spacer(modifier = Modifier.size(cellSize).padding(1.dp))
                        }
                    }
                }
            }
        }
    }
}
