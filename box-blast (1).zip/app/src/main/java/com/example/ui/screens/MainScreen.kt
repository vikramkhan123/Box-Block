package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import com.example.ui.theme.*

@Composable
fun MainScreen(
    onNavigateToAdventure: () -> Unit,
    onNavigateToClassic: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(BackgroundGradientStart, BackgroundGradientEnd)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(16.dp)
        ) {
            // Massive 3D Styled Title
            Text(
                text = "BOX BLAST",
                style = TextStyle(
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    shadow = Shadow(
                        color = Color.Black.copy(alpha = 0.5f),
                        offset = Offset(0f, 10f),
                        blurRadius = 15f
                    )
                ),
                modifier = Modifier.padding(bottom = 60.dp)
            )

            // Adventure Master Button
            MenuButton(
                text = "Adventure Master",
                startColor = ButtonAdventureStart,
                endColor = ButtonAdventureEnd,
                onClick = onNavigateToAdventure
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Classic Box Blast Button
            MenuButton(
                text = "Classic Box Blast",
                startColor = ButtonClassicStart,
                endColor = ButtonClassicEnd,
                onClick = onNavigateToClassic
            )
        }
    }
}

@Composable
fun MenuButton(
    text: String,
    startColor: Color,
    endColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(64.dp)
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .background(
                brush = Brush.horizontalGradient(colors = listOf(startColor, endColor)),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            style = TextStyle(
                shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.4f),
                    offset = Offset(0f, 4f),
                    blurRadius = 4f
                )
            )
        )
    }
}
