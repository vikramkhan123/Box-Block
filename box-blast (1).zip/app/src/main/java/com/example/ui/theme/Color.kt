package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Game Colors
val BackgroundGradientStart = Color(0xFF0F0F2D)
val BackgroundGradientEnd = Color(0xFF2C1045)
val GridBackground = Color(0xFF0A102A)
val GridCellEmpty = Color(0xFF161F40)
val GridCellBorder = Color(0xFF2A3660)

// Block Colors (Darker for embedding effect)
val BlockCrimson = Color(0xFF600010)
val BlockIndigo = Color(0xFF180A45)
val BlockForest = Color(0xFF0B3B15)
val BlockCharcoal = Color(0xFF202020)
val BlockTeal = Color(0xFF003030)
val BlockOrange = Color(0xFF502000)

val BlockColors = listOf(BlockCrimson, BlockIndigo, BlockForest, BlockCharcoal, BlockTeal, BlockOrange)

// Gem Colors (Neon/Bright)
val GemStarGold = Color(0xFFFFD700)
val GemDiamondIce = Color(0xFF00FFFF)
val GemHotPink = Color(0xFFFF00FF)

// UI Colors
val ButtonAdventureStart = Color(0xFFFF512F)
val ButtonAdventureEnd = Color(0xFFDD2476)
val ButtonClassicStart = Color(0xFF11998E)
val ButtonClassicEnd = Color(0xFF38EF7D)
